//
//  ViewController.swift
//  ReconnaissanceGeste
//
//  Created by Camille Guinaudeau on 08/03/2018.
//  Copyright © 2018 Camille Guinaudeau. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIGestureRecognizerDelegate {
    
    @IBOutlet var handlepan: UIPanGestureRecognizer!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func Handle(_ sender: UIPanGestureRecognizer) {
        let translation = sender.translation(in: self.view)
        if let view = sender.view {
            view.center = CGPoint(x:view.center.x + translation.x,
                                  y:view.center.y + translation.y)
        }
        sender.setTranslation(CGPoint.zero, in: self.view)
        if sender.state == UIGestureRecognizerState.ended {
            // 1
            let velocity = sender.velocity(in: self.view); let magnitude = sqrt((velocity.x * velocity.x) +
                (velocity.y * velocity.y))
            let slideMultiplier = magnitude / 200
            // 2
            let slideFactor = 0.1 * slideMultiplier
            // 3
            var finalPoint = CGPoint(x:sender.view!.center.x +   (velocity.x * slideFactor), y:sender.view!.center.y +   (velocity.y * slideFactor))
            // 4
            finalPoint.x = min(max(finalPoint.x, 0),   self.view.bounds.size.width)
            finalPoint.y = min(max(finalPoint.y, 0),   self.view.bounds.size.height)
            // 5
            UIView.animate(withDuration: Double(slideFactor * 2), delay: 0,
                           options: UIViewAnimationOptions.curveEaseOut,
                           animations: {sender.view!.center = finalPoint },
                           completion: nil)
                           
    }
}

    @IBAction func handlePinch(_ sender: UIPinchGestureRecognizer) {if let view = sender.view {
        view.transform = view.transform.scaledBy(x: sender.scale,y: sender.scale)
                                                 sender.scale = 1
        }
    }
    
    @IBAction func handleRotate(_ sender: UIRotationGestureRecognizer) {
        if let view = sender.view {
            view.transform = view.transform.rotated(by: sender.rotation)
            sender.rotation = 0
        }
    }
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,   shouldRecognizeSimultaneouslyWith
        otherGestureRecognizer: UIGestureRecognizer) -> Bool { if gestureRecognizer is UIPanGestureRecognizer ||   gestureRecognizer is UIPinchGestureRecognizer {
        return true
    } else {
        return false
        }
        
    }
    
    @IBAction func handleswap(_ sender: UISwipeGestureRecognizer) { if sender.direction == .right {
        // Create the alert controller
            let alertController = UIAlertController(title: "Bravo", message: "J'ai réussi !", preferredStyle: .alert)
        
        // Create the actions
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default) {
            UIAlertAction in
            NSLog("OK Pressed")
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel) {
            UIAlertAction in
            NSLog("Cancel Pressed")
        }
        
        // Add the actions
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        
        // Present the controller
        self.present(alertController, animated: true, completion: nil)
        }
        if sender.direction == .left {    // Create the alert controller
            let alertController = UIAlertController(title: "Bravo", message: "J'ai réussi !", preferredStyle: .alert)
            
            // Create the actions
            let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default) {
                UIAlertAction in
               
            }
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel) {
                UIAlertAction in
                
            }
            
            // Add the actions
            alertController.addAction(okAction)
            alertController.addAction(cancelAction)
            
            // Present the controller
            self.present(alertController, animated: true, completion: nil)}
    }
 
}

