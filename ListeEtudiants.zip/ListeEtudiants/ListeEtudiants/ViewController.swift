//
//  ViewController.swift
//  ListeEtudiants
//
//  Created by Camille Guinaudeau on 04/03/2019.
//  Copyright © 2019 Camille Guinaudeau. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var table: UITableView!
    var data : [Etudiant] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        table.dataSource = self
        table.delegate = self
        let etud1 = Etudiant()
        let etud2 = Etudiant(civilite: "H", nom: "BO", prenom: "Henri", nbrAbs: 0, redouble: false, numEud: "210525")
        let etud3 = Etudiant()
        
      
        data.append(etud1)
        data.append(etud2)
        data.append(etud3)
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Récupérons le bon élément
        let d = data[indexPath.row]
        
        // Création d'une cellule
        let cellIdentifier = "ElementCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier)
            ?? UITableViewCell(style: .subtitle, reuseIdentifier: cellIdentifier)
        
        // Paramétrage de l'affichage
        if d.redouble {
            cell.accessoryType = UITableViewCell.AccessoryType.checkmark
        }
        
        cell.textLabel?.textColor = UIColor.black
        cell.detailTextLabel?.textColor = UIColor.black
        if d.nbrAbs > 5 {
            cell.textLabel?.textColor = UIColor.red
            cell.detailTextLabel?.textColor = UIColor.red
        }
        
        // On y ajoute les bonnes informations
        cell.textLabel?.text = d.nom + " " + d.prenom
        cell.detailTextLabel?.text = String(d.nbrAbs)
        
        // On retourne la cellule
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(data[indexPath.row].description)
    }
    
    @IBAction func miseAjourTableView(segue : UIStoryboardSegue){
        table.reloadData()
    }

}

