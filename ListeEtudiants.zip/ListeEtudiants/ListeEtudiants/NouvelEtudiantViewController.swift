//
//  NouvelEtudiantViewController.swift
//  ListeEtudiants
//
//  Created by Henri Bo on 06/03/2019.
//  Copyright © 2019 Camille Guinaudeau. All rights reserved.
//

import UIKit

class NouvelEtudiantViewController: UIViewController,UITextFieldDelegate {
    var etudiantCourant = Etudiant()
    @IBOutlet weak var Nom: UITextField!
    
    @IBOutlet weak var redouble: UISwitch!
    @IBOutlet weak var civile: UISegmentedControl!
    @IBOutlet weak var Enregistrer: UIButton!
    @IBOutlet weak var Step: UIStepper!
    @IBOutlet weak var NombreAbs: UILabel!
    @IBOutlet weak var numeroEtud: UITextField!
    @IBOutlet weak var Prenom: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

  
        
        Nom.delegate = self
        Prenom.delegate = self
        numeroEtud.delegate = self
       
        Enregistrer.isEnabled = false
        // Do any additional setup after loading the view.
    }
    

    @IBAction func ChangerNombre(_ sender: Any) {
        Step = (sender as! UIStepper)
        NombreAbs.text = String (Int (Step.value))
        
    }
    @IBAction func Enregistrer(_ sender: Any) {
        var civ = "Monsieur"
        if (civile.selectedSegmentIndex == 0) {
            civ = "Monsieur"
        }
        if (civile.selectedSegmentIndex == 1) {
            civ = "Madame"
        }
        if (civile.selectedSegmentIndex == 2) {
            civ = "Mademoiselle"
        }
        
        var nombre = Int (Step.value)
        
        etudiantCourant = Etudiant(civilite: civ, nom: Nom.text!, prenom: Prenom.text!, nbrAbs: nombre
            , redouble: redouble.isOn, numEud: numeroEtud.text!)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if(!(Nom.text?.isEmpty)! && !(Prenom.text?.isEmpty)! && !(numeroEtud.text?.isEmpty)! ){
            Enregistrer.isEnabled = true
        }
        
        return false ;
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
      
            let destination = segue.destination as! ViewController
            destination.data += [etudiantCourant]
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
