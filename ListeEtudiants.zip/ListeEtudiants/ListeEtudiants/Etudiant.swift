//
//  Etudiant.swift
//  ListeEtudiants
//
//  Created by Henri Bo on 06/03/2019.
//  Copyright © 2019 Camille Guinaudeau. All rights reserved.
//

import Foundation
class Etudiant {
    var civilite: String
    var nom: String
    var prenom: String
    var numEtud: String
    var nbrAbs: Int
    var redouble : Bool
    // Pour voir les attributs
    var description: String {
        return "\(civilite) \(nom) \(prenom)\n Numero etudiant : \(numEtud)\n Nombre d'absence: \(nbrAbs) \(redouble) "
    }
    init(civilite: String, nom: String, prenom: String,  nbrAbs: Int,redouble:Bool , numEud:String) {
        self.civilite = civilite
        self.nom = nom
        self.prenom = prenom
        self.numEtud = numEud
        self.nbrAbs = nbrAbs
        self.redouble = redouble
    }
    
    convenience init() {
        self.init(civilite: "H", nom:"Smith", prenom:"John", nbrAbs: 0, redouble:false,numEud:"21")
    }
}
